References:-

Python documentations
Pandas documentations
Datetime documentations

https://www.geeksforgeeks.org/title-in-python/

https://www.w3resource.com/pandas/series/series-idxmax.php